<?php
/**
 * Plugin Name: HypeBuy&Sell Final Marketplace Suite
 * Description: Vendor dashboard, checkout, homepage, analytics, Elementor-ready WooCommerce toolkit.
 * Version: 1.1
 * Author: Hype-h
 */
require_once plugin_dir_path(__FILE__) . 'includes/checkout-functions.php';
