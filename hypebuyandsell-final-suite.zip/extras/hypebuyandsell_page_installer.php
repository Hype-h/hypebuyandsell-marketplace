<?php
/** Auto-creates essential pages for HypeBuy&Sell plugin */
function hbsvd_create_plugin_pages() {
    $pages = [
    {
        "title": "Checkout",
        "slug": "checkout",
        "shortcode": "[hbsvd_checkout]"
    },
    {
        "title": "Order Confirmation",
        "slug": "order-confirmation",
        "shortcode": "[hbsvd_thank_you]"
    },
    {
        "title": "Product Showcase",
        "slug": "product-showcase",
        "shortcode": "[hbsvd_product_grid]"
    },
    {
        "title": "Vendors",
        "slug": "vendors",
        "shortcode": "[hbsvd_vendor_list]"
    },
    {
        "title": "Homepage",
        "slug": "home",
        "shortcode": "[hbsvd_homepage]"
    }
];
    foreach ($pages as $page) {
        if (!get_page_by_path($page['slug'])) {
            wp_insert_post(array(
                'post_title'     => $page['title'],
                'post_name'      => $page['slug'],
                'post_content'   => $page['shortcode'],
                'post_status'    => 'publish',
                'post_type'      => 'page',
            ));
        }
    }
}
register_activation_hook(__FILE__, 'hbsvd_create_plugin_pages');
