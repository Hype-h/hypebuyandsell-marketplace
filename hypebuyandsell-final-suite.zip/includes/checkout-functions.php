
<?php
/**
 * WooCommerce-Compatible Full Marketplace Suite for HypeBuy&Sell
 * Includes: Checkout, Thank You, Product Display, Vendor List, Homepage Layout, Analytics Dashboard, Vendor Dashboard
 */

// Existing shortcodes remain unchanged ...

// 9. Vendor Dashboard Shortcode
function hbsvd_vendor_dashboard_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>You must be logged in to view your vendor dashboard.</p>';
    }

    $user_id = get_current_user_id();
    $store_url = function_exists('wcfm_get_vendor_store_url') ? wcfm_get_vendor_store_url($user_id) : '#';

    ob_start();
    ?>
    <div class="hbsvd-vendor-dashboard">
        <h2>📦 Vendor Dashboard</h2>
        <ul class="hbsvd-vendor-menu">
            <li><a href="/shop-manager/products">Manage Products</a></li>
            <li><a href="/shop-manager/orders">View Orders</a></li>
            <li><a href="/shop-manager/coupons">Coupons</a></li>
            <li><a href="/shop-manager/reports">Reports</a></li>
            <li><a href="/shop-manager/settings">Store Settings</a></li>
            <li><a href="<?php echo esc_url($store_url); ?>">View Storefront</a></li>
        </ul>
        <div class="hbsvd-analytics-summary">
            <?php echo do_shortcode('[hbsvd_analytics]'); ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('hbsvd_vendor_dashboard', 'hbsvd_vendor_dashboard_shortcode');

// Append styles
add_action('wp_head', function() {
    echo '<style>
    .hbsvd-vendor-dashboard {
        background: #fff; padding: 20px; border-radius: 10px; margin: 30px auto; max-width: 800px; box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .hbsvd-vendor-menu {
        display: flex; flex-wrap: wrap; justify-content: space-between;
        list-style: none; padding: 0; margin: 0 0 20px;
    }
    .hbsvd-vendor-menu li {
        flex: 1 1 45%; margin: 5px 0;
    }
    .hbsvd-vendor-menu a {
        display: block; background: #0073aa; color: #fff; text-align: center; padding: 10px; border-radius: 6px; text-decoration: none;
    }
    .hbsvd-vendor-menu a:hover {
        background: #005077;
    }
    </style>';
});

/**
 * Additional Shortcodes:
 * - [hbsvd_vendor_dashboard] — Vendor panel with links and analytics
 */
