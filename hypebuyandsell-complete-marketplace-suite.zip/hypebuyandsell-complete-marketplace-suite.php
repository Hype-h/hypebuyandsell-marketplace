<?php
/**
 * Plugin Name: HypeBuy&Sell Marketplace Complete Suite
 * Description: Complete WooCommerce plugin with vendor dashboard and stylized marketplace pages.
 * Version: 1.1.0
 * Author: Hype-h
 */

require_once plugin_dir_path(__FILE__) . 'includes/checkout-functions.php';
require_once plugin_dir_path(__FILE__) . 'includes/core-pages.php';
